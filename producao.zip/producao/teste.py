import numpy as np
import time
import datetime
import os
import glob
import pandas as pd
import csv
from xlsxwriter.workbook import Workbook
import interacoes_selenium as IS
from sqlalchemy import create_engine
import pymysql
from dateutil.relativedelta import *

var = 1

print('A var é {}'.format(var))